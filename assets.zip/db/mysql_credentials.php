<?php

function getServerName()
{
    //Localhost
    return $servername = "localhost";
}
function getUserName()
{
    return $username = "wordbite";
}

function getUserPassword()
{
    return  $password = "Rumpastasara@193";
}
function getDatabaseName()
{
    return $dbname = "wordbite_wordbite";
}
?>