<?php
require_once("./mysql_credentials.php");

function connection(){
    $con = new mysqli(getServerName(),getUserName(),getUserPassword(),getDatabaseName());
    return $con;
}

?>
