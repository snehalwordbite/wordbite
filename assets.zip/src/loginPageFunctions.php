<?php

//require("db/mysql_credentials.php");

function loginUser($username,$passwordHash){
    $query = "SELECT * FROM wb_customers WHERE customer_username='".$username."' AND salt='".$passwordHash."'";
     $con = new mysqli(getServerName(),getUserName(),getUserPassword(),getDatabaseName());
        $result = mysqli_query($con,$query);
        if($result){
            return true;
        }else{
            return false;
        }
}
?>

