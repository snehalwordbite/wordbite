<?php

//require("db/mysql_credentials.php");

function checkPassword($password1, $password2){
    if($password1==$password2){
        return true;
    }
    return false;
}

if(isset($_GET['username'])){
    $username = $_GET['username'];
    $query = "SELECT * FROM wb_customers WHERE customer_username='$username'";
     $con = new mysqli(getServerName(),getUserName(),getUserPassword(),getDatabaseName());

    try{
        $result = mysqli_query($con,$query);
        if($result){
            echo "true";
        }else{
            echo "false";
        }
    }catch(Exception $e){
        return "error";
    }
}

function registerUser($email,$firstName,$lastName,$password,$dateOfBirth,$gender,$mobileNumber,$uniqueName){
    $saltPassword = md5($password);
    $customer_id="";
         $con = new mysqli(getServerName(),getUserName(),getUserPassword(),getDatabaseName());
    $query = "INSERT INTO wb_customers(customer_username,email,password,salt,role_id) VALUES('$uniqueName',$email','$password','$saltPassword',0)";
    try{
        $result=mysqli_query($con,$query);
        if($result){
            $queryForCustomerID="select id from wb_customers where customer_username='$uniqueName";
            $result=mysqli_query($con,$queryForCustomerID);
             if($result){
                 while($row = mysqli_fetch_assoc($result)) {
                      $customer_id=  $row["id"];
                      }
             }
        $queryForCustomerDetails = "INSERT INTO wb_customers_details(fname,lname,email,birthdate,gender,customer_id,mobile,full_name,uniqueName) VALUES('$firstName','$lastName','$email','$dateOfBirth','$gender','$customer_id','$mobileNumber','$firstName'+' $lastName','$uniqueName')";
        // adding data to wb_customer_details table
        $result=mysqli_query($con,$queryForCustomerDetails);
        
        echo '<script>alert("Registration Successful!");</script>';
        session_start();
        $_SESSION['username'] = $uniqueName;
        $_SESSION['fullname'] = $firstName+' '+$lastName;
        $_SESSION['isloggedIn'] = true;
        header("Location:../modules/profile.php");
        }
    }catch(Exception $e){
        echo $e->getMessage();
    }
}


?>