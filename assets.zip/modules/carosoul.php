<div class="row col-lg-12">
<div class="d-flex justify-content-center">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner" style="height:150px;">
    <div class="carousel-item active">
      <img src="https://i.pinimg.com/originals/a8/c8/cd/a8c8cd1c0ff7f448c5958cf73f9ff5e1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://wallpapercave.com/wp/wp4064613.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://pixelz.cc/wp-content/uploads/2018/07/vintage-book-uhd-4k-wallpaper.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
</div>
