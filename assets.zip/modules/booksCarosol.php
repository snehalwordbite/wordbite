<div id="carouselExampleControls" class="carousel slide col-12" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="row">
        <div class="col-2">
          <div class="card h-75">
            <a href="./particularBook.php">
              <img src="https://m.media-amazon.com/images/I/41gr3r3FSWL.jpg" style="height:370px;"
                class="card-img-top shadow-sm bg-white rounded" alt="...">
            </a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75">
            <a href="./particularBook.php">
              <img src="https://blog.creatopy.com/wp-content/uploads/2020/08/The-Great-Gatsby-Book-Cover-391x600.jpg"
                class="card-img-top shadow-sm bg-white rounded" style="height:370px;" alt="..."></a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75">
            <a href="./particularBook.php">
              <img src="https://m.media-amazon.com/images/I/41gr3r3FSWL.jpg" style="height:370px;"
                class="card-img-top shadow-sm bg-white rounded" alt="...">
            </a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75"><a href="./particularBook.php">
              <img src="https://i.pinimg.com/564x/8e/b9/63/8eb963b5794dd3f9aeb7cf19a59e659f.jpg"
                class="card-img-top shadow-sm bg-white rounded" style="height:370px;" alt="..."></a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75"><a href="./particularBook.php">
              <img
                src="https://d1csarkz8obe9u.cloudfront.net/posterpreviews/contemporary-fiction-night-time-book-cover-design-template-1be47835c3058eb42211574e0c4ed8bf_screen.jpg?ts=1594616847"
                class="card-img-top shadow-sm bg-white rounded" style="height:370px;" alt="..."></a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75"><a href="./particularBook.php">
              <img src="https://i.pinimg.com/564x/8e/b9/63/8eb963b5794dd3f9aeb7cf19a59e659f.jpg"
                class="card-img-top shadow-sm bg-white rounded" style="height:370px;" alt="..."></a>
          </div>
        </div>
      </div>
    </div>

    <!-- item-2 -->
    <div class="carousel-item">
      <div class="row">
        <div class="col-2">
          <div class="card h-75"><a href="./particularBook.php">
              <img src="https://m.media-amazon.com/images/I/41gr3r3FSWL.jpg" style="height:370px;"
                class="card-img-top shadow-sm bg-white rounded" alt="..."></a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75"><a href="./particularBook.php">
              <img src="https://blog.creatopy.com/wp-content/uploads/2020/08/The-Great-Gatsby-Book-Cover-391x600.jpg"
                class="card-img-top shadow-sm bg-white rounded" style="height:370px;" alt="..."></a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75"><a href="./particularBook.php">
              <img src="https://i.pinimg.com/564x/8e/b9/63/8eb963b5794dd3f9aeb7cf19a59e659f.jpg"
                class="card-img-top shadow-sm bg-white rounded" style="height:370px;" alt="..."></a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75"><a href="./particularBook.php">
              <img src="https://blog.creatopy.com/wp-content/uploads/2020/08/The-Great-Gatsby-Book-Cover-391x600.jpg"
                class="card-img-top shadow-sm bg-white rounded" style="height:370px;" alt="..."></a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75"><a href="./particularBook.php">
              <img
                src="https://d1csarkz8obe9u.cloudfront.net/posterpreviews/contemporary-fiction-night-time-book-cover-design-template-1be47835c3058eb42211574e0c4ed8bf_screen.jpg?ts=1594616847"
                class="card-img-top shadow-sm bg-white rounded" style="height:370px;" alt="..."></a>
          </div>
        </div>
        <div class="col-2">
          <div class="card h-75"><a href="./particularBook.php">
              <img src="https://blog.creatopy.com/wp-content/uploads/2020/08/The-Great-Gatsby-Book-Cover-391x600.jpg"
                class="card-img-top shadow-sm bg-white rounded" style="height:370px;" alt="..."></a>
          </div>
        </div>
      </div>
    </div>
    <!-- end-of-item2 -->
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>