<div class="d-flex flex-row my-2">
    <div class="d-flex mr-auto mx-2">
        <i class="bi-chat-quote" style="font-size: 25px; color: blue;"></i>
        <h3 class="display-6 mx-3" style="color: blue;">Blogs</h3>
        <div class="col-12">
        </div>
    </div>
    <hr class="col-8">
    <div class="d-flex ml-auto mx-2 align-text-center">
        <h2><a href="#" class="btn btn-link">View More</a></h2>
    </div>
</div>
<div class="d-flex flex-row mx-2 my-2 justify-content-center">
<?php require "./booksCarosol.php" ?>
</div>