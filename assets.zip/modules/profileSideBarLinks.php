<div class="scrollspy-example shadow mb-2 bg-white rounded">
    <a class="list-group-item list-group-item-action" href="#">
        Feeds
    </a>
    <a class="list-group-item list-group-item-action" href="#">
        Following
    </a>
    <a class="list-group-item list-group-item-action" href="#">
        Followers
    </a>
    <a class="list-group-item list-group-item-action" href="#">
        Drafts
    </a>
    <a class="list-group-item list-group-item-action" href="#">
        Published
    </a>
    <a class="list-group-item list-group-item-action" href="#">
        Wallet
    </a>
    <a class="list-group-item list-group-item-action" href="#">
        Library
    </a>
    <a class="list-group-item list-group-item-action" href="#">
        Profile
    </a>
    <a class="list-group-item list-group-item-action" href="#">
        Edit Profile
    </a>
</div>