    <div class="col-md-3 col-xl-2 bd-sidebar">
        <?php
        require('./profileCard.php');
        ?>
        <div id="list-example" class="list-group my-3 justify-content-center">
                <?php
            require('./profileSideBarLinks.php');
        ?>
        </div>
    </div>