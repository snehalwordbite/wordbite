
    <div class="bd-toc-item">
        <a class="bd-toc-link" href="#">
            Feeds
        </a>
        <ul class="nav bd-sidenav">
            <li>
                <a href="#">
                    Following
                </a>
            </li>
            <li>
                <a href="#">
                    Followers
                </a>
            </li>
        </ul>
    </div>
    <div class="bd-toc-item">
        <a class="bd-toc-link" href="#">
            Drafts
        </a>
    </div>
    <div class="bd-toc-item">
        <a class="bd-toc-link" href="#">
            Published
        </a>
    </div>
    <div class="bd-toc-item">
        <a class="bd-toc-link" href="#">
            Wallet
        </a>
    </div>
    <div class="bd-toc-item">
        <a class="bd-toc-link" href="#">
            Library
        </a>
    </div>
    <div class="bd-toc-item">
        <a class="bd-toc-link" href="#">
            Profile
        </a>
    </div>
    <div class="bd-toc-item">
        <a class="bd-toc-link" href="#">
            Edit Profile
        </a>
    </div>