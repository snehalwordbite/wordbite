    <div class="col-md-3 col-xl-2 bd-sidebar">
        <?php
        require('./components/profileCard.php');
        ?>
        <div class="collapse d-md-block row" id="bd-docs-nav">
            <nav class="bd-links" aria-label="Main navigation">
                <?php
            require('./components/profileSideBarLinks.php');
        ?>
            </nav>
        </div>
    </div>